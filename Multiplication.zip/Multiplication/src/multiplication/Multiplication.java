
package multiplication;


public class Multiplication {

    
    public static void main(String[] args) {
       
     Test frame = new Test();
        frame.setVisible(true);
        frame.setTitle("Multiplication Azad");
        frame.setBounds(500,0, 400, 650);
        frame.setResizable(false);
        
        
    }
    
}
